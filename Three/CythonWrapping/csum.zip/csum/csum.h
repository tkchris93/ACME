extern double csum(double* a);
